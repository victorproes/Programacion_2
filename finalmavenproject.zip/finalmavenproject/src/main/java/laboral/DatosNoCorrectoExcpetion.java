package laboral;

public class DatosNoCorrectoExcpetion extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1182558612260381610L;

	public DatosNoCorrectoExcpetion(String mensaje) {
		super(mensaje);
		// TODO Auto-generated constructor stub
	}
}
